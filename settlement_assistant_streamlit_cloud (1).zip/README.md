# 정산 비서 AI

Streamlit + LangGraph + OpenAI 기반 교육용 정산 비서입니다.

## Run

```bash
streamlit run streamlit_app.py
```
